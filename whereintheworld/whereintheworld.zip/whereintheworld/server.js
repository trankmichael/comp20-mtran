// Initialization
var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator'); // See documentation at https://github.com/chriso/validator.js
var app = express();
// See https://stackoverflow.com/questions/5710358/how-to-get-post-query-in-express-node-js
app.use(bodyParser.json());
// See https://stackoverflow.com/questions/25471856/express-throws-error-as-body-parser-deprecated-undefined-extended
app.use(bodyParser.urlencoded({ extended: true }));

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/test';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
	db = databaseConnection;
});

app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.post('/sendLocation', function(request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	var login = "";
	var lat = ""; 
	var lng = ""; 
	var timestamp = new Date();

	login = request.body.login;
	lat = request.body.lat;
	lng = request.body.lng;

	if( (login != null) && (lat != null) && (lng != null) ) {
		var docToInsert = {
			"created_at" : timestamp,
			"login": login,
			"lat":lat,
			"lng": lng,
		};

		db.collection('students', function(er, collection) {
			var id = collection.insert(docToInsert, function(err, saved) {
				if (err) {
					response.send(500);
				}
				else {
					db.collection('students', function(er, collection) {
						collection.find().toArray(function(err, cursor) {
							response.send(cursor);
						});
					});
				}
		    });
		});
	} else {
		response.send(200);
	}
});

app.get('/locations.json', function(request, response) {
	response.setHeader("Content-Type", "application/json");
	var name = request.param("login");

	db.collection('students', function(er, collection) {
		collection.find({login: name}).toArray(function(err, cursor) {
			response.send(cursor);
		});
	});
});

app.get('/redline.json', function(request, response) {
	response.setHeader("Content-Type", "application/json");
	var http = require('http');
	var options = {
	  host: 'developer.mbta.com',
	  port: 80,
	  path: '/lib/rthr/red.json'
	};

	http.get(options, function(res) {
		var data = '';
		console.log("Got response: " + res.statusCode);

		res.on('data', function(chunk) {
			data += chunk
			console.log("BODY: " + chunk);
		});

		res.on('end', function() {
			response.send(data);
		});
	}).on('error', function(e) {
		console.log("Got error: " + e.message);
	});

});

app.get('/', function(request, response) {
	response.set('Content-Type', 'text/html');
	var indexPage = '';
	db.collection('students', function(er, collection) {
		collection.find().toArray(function(err, cursor) {
			if (!err) {
				indexPage += "<!DOCTYPE HTML><html><head><title>Check-ins</title></head><body><h1>Check-ins</h1>";
				for (var count = 0; count < cursor.length; count++) {
					indexPage += "<p>Timestamp: " + cursor[count].created_at + 
					" Login: " + cursor[count].login + " Latitude: " + cursor[count].lat +
					" Longitude: " + cursor[count].lng + "</p>";
				}
				indexPage += "</body></html>"
				// collection.drop();
				response.send(indexPage);
			} else {
				response.send('<!DOCTYPE HTML><html><head><title>Check-ins</title></head><body><h1>Whoops, something went terribly wrong!</h1></body></html>');
			}
		});
	});
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);